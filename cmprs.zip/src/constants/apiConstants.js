export const API_BASE_URL = 'http://kycdigi.ae:4002/users/'
export const ACCESS_TOKEN_NAME = 'localStorage.getItem(ACCESS_TOKEN_NAME)'
export const personalinfobaseURL =
  'http://kycdigi.ae:4002/personal/personalinfo'
