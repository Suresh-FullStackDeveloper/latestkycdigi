import React, { useState } from 'react'
import axios from 'axios'
import './RegistrationForm.css'
import { API_BASE_URL, ACCESS_TOKEN_NAME } from '../../constants/apiConstants'
import { withRouter } from 'react-router-dom'

function RegistrationForm (props) {
  const [state, setState] = useState({
    username: '',
    password: '',
    phone: '',
    //confirmPassword: '',
    successMessage: null
  })
  const handleChange = e => {
    const { id, value } = e.target
    setState(prevState => ({
      ...prevState,
      [id]: value
    }))
  }
  const sendDetailsToServer = () => {
    // if (state.username.length && state.password.length) {
    //   props.showError(null)
    const payload = {
      username: state.username,
      phoneNumber: state.phone,
      password: state.password
    }
    axios
      .post('http://kycdigi.ae:4002/users/register', payload)
      .then(result => {
        debugger
        console.log(result.data)
        if (result.status === 400) {
          alert('Invalid User')
        } else {
          localStorage.setItem('token', JSON.stringify(result.data.token))
          localStorage.setItem('id', JSON.stringify(result.data.id))

          redirectToHome()
        }
      })
  }

  const redirectToHome = () => {
    // props.updateTitle('Home')
    props.history.push('/dashboard')
  }
  const redirectToLogin = () => {
    props.updateTitle('Login')
    props.history.push('/login')
  }
  const handleSubmitClick = e => {
    e.preventDefault()
    //props.history.push('/dashboard')

    sendDetailsToServer()
  }
  return (
    <div className='card col-12 col-lg-4 login-card mt-2 hv-center'>
      <form>
        <div className='form-group text-left'>
          <label htmlFor='exampleInputEmail1'>User Name</label>
          <input
            type='username'
            className='form-control'
            id='username'
            aria-describedby='usernameHelp'
            placeholder='Enter username'
            value={state.username}
            onChange={handleChange}
          />
        </div>
        <div className='form-group text-left'>
          <label htmlFor='exampleInputPassword1'>Password</label>
          <input
            type='password'
            className='form-control'
            id='password'
            placeholder='Password'
            value={state.password}
            onChange={handleChange}
          />
        </div>
        <div className='form-group text-left'>
          <label htmlFor='exampleInputPassword1'>Phone</label>
          <input
            type='phone'
            className='form-control'
            id='phone'
            placeholder='Enter your Phone Number'
            value={state.phone}
            onChange={handleChange}
          />
        </div>
        <button
          type='submit'
          className='btn btn-primary'
          onClick={handleSubmitClick}
        >
          Register
        </button>
      </form>
      <div
        className='alert alert-success mt-2'
        style={{ display: state.successMessage ? 'block' : 'none' }}
        role='alert'
      >
        {state.successMessage}
      </div>
      <div className='mt-2'>
        <span>Already have an account? </span>
        <span className='loginText' onClick={() => redirectToLogin()}>
          Login here
        </span>
      </div>
    </div>
  )
}

export default withRouter(RegistrationForm)
