import React, { Component, useState } from 'react'
import { Stepper } from 'react-form-stepper'
import '../../App.css'

class IndPersonalDetails extends Component {
  continue = e => {
    e.preventDefault()
    // const isFirstNameValid = this.props.validateFirstName()
    //   const isLastNameValid = this.props.validateLastName()
    // if (isFirstNameValid && isLastNameValid) {
    //   this.props.nextStep()
    // }
    this.props.nextStep()
  }
  // IndPersonalDetails = () => {
  //   /*  Initial State */
  //   let [firstname, setname] = useState('')

  //   /* The handleChange() function to set a new state for input */
  //   const handleChange = event => {
  //     setname(event.target.value)
  //   }
  // }

  render () {
    const { values } = this.props

    // const {
    //   //firstname,
    //   middlename,
    //   lastname,
    //   residentialstatus,
    //   area,
    //   district,
    //   city,
    //   emiratesorstate,
    //   province,
    //   country,
    //   temporaryaddress,
    //   permanentaddress,
    //   completepermanentaddress,
    //   nationality,
    //   dateofbirth,
    //   coutnryofbirth,
    //   mobilenumber,

    //   // email,
    //   // phone,
    //   handleChange,
    //   validateFirstName,
    //   validateLastName,
    //   isErrorFirstName,
    //   isErrorLastName,
    //   errorMessageFirstName,
    //   errorMessageLastName,
    //   validateMiddleName,
    //   isErrorMiddleName,
    //   errorMessageMiddleName,
    //   ResidentialStatus,
    //   isErrorResidentialStatus,
    //   errorMessageResidentialStatus,
    //   Area,
    //   isErrorArea,
    //   errorMessageArea,
    //   // City,
    //   // isErrorcity,
    //   // errorMessagecity,
    //   // isErroremiratesorstate,
    //   // errorMessageemiratesorstate,
    //   // isErrorprovince,
    //   // errorMessageemiratesorprovince,
    //   // isErrorcountry,
    //   // errorMessageemiratesorcountry,
    //   // isErrortemporaryaddress,
    //   // errorMessagetemporaryaddress,
    //   // isErrorpermanentaddress,
    //   // errorMessagepermanentaddress,
    //   // isErrorcompletepermanentaddress,
    //   // errorMessagecompletepermanentaddress,
    //   // isErrornationality,
    //   // errorMessagenationality,
    //   isErrordateofbirth,
    //   errorMessagedateofbirth,
    //   isErrorcoutnryofbirth,
    //   errorMessagecoutnryofbirth
    // } = this.props

    return (
      // <div className='form'>
      <form>
        <Stepper
          steps={[
            { label: 'Personal details' },
            { label: 'Address details' },
            { label: 'Payment Details' },
            { label: 'Summary' }
          ]}
          activeStep={0}
          styleConfig={{
            activeBgColor: '#2b7cff',
            activeTextColor: '#fff',
            inactiveBgColor: '#fff',
            inactiveTextColor: '#2b7cff',
            completedBgColor: '#fff',
            completedTextColor: '#2b7cff',
            size: '3em'
          }}
          className={'stepper'}
          stepClassName={'stepper__step'}
        />

        <div className='form-group'>
          <div className='form-group__element'>
            <label htmlFor='first name' className='form-group__label'>
              First Name
            </label>
            <input
              type='text'
              onChange={this.props.handleChange('firstName')}
              defaultValue={values.firstName}
              className='form-group__input'
            />
            {/* <p className='error'>{isErrorFirstName && errorMessageFirstName}</p> */}
          </div>
        </div>

        <div style={{ textAlign: 'center' }}>
          <button
            className='buttons__button buttons__button--next'
            onClick={this.continue}
          >
            Next
          </button>
        </div>
      </form>
      // </div>
    )
  }
}

export default IndPersonalDetails
