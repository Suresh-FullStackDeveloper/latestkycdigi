import React, { Component } from 'react'
import { Stepper } from 'react-form-stepper'
import '../../App.css'

class CorpPaymentDetails extends Component {
  //   shouldComponentUpdate (nextProps) {
  //     if (
  //       this.props.emiratesid !== nextProps.isEmiratesId ||
  //       this.props.level !== nextProps.level
  //     ) {
  //       return true
  //     } else {
  //       return false
  //     }
  //   }
  continue = e => {
    e.preventDefault()
    //const isEmiratesId = this.props.validateEmiratesId()
    // const isPassport = this.props.validatePassport()
    // if (isEmiratesId && isPassport) {
    this.props.nextStep()
    //  }
  }

  render () {
    const {
      tradelicense,
      Tradelicensenumber,
      Tradelicenseplaceofissue,
      Tradelicenseissuedate,
      Tradelicenseexpirydate,
      Typeofbusinessoftheentity,
      Shareholders,
      Partners,
      NamesofUBO,
      IDdetailsofUBO,
      IDtypeofUBO,
      IDnumbersofUBO,
      Methodofpayment,
      cash,
      cheque,
      Nameofthepersonrepresentingtheentity,
      IDtypeofAuthPerson,
      IDnumbersofAuthPerson,
      Sourceoffunds,
      Purposeoftransaction,
      Beneficiaryname,
      bankaccountdetails,
      Expectedannualactivity,
      expectedannualvalue,
      numberoftransactionsfuturetransmonitoring,
      // email,
      // phone,
      handleChange,
      //   validateFirstName,
      //   validateLastName,
      //   isErrorFirstName,
      //   isErrorLastName,
      //   errorMessageFirstName,
      //   errorMessageLastName
      validateprofession,
      isErrorProfession,
      isErrorbeneficiaryname,
      errorMessagebeneficiaryname,
      isErrorexpectedannualactivity,
      errorMessageexpectedannualactivity,

      errorMessageProfession,
      validateCashorcheque,
      validateSourceofFunds
    } = this.props

    return (
      <div className='form'>
        <form>
          <Stepper
            steps={[
              { label: 'Personal details' },
              { label: 'Address details' },
              { lable: 'Payment Details' },
              { label: 'Summary' }
            ]}
            activeStep={4}
            styleConfig={{
              activeBgColor: '#2b7cff',
              activeTextColor: '#fff',
              inactiveBgColor: '#fff',
              inactiveTextColor: '#2b7cff',
              completedBgColor: '#fff',
              completedTextColor: '#2b7cff',
              size: '3em'
            }}
            className={'stepper'}
            stepClassName={'stepper__step'}
          />

          <div className='form-group'>
            <div className='form-group__element'>
              <label htmlFor='tradelicense' className='form-group__label'>
                tradelicense
              </label>
              <input
                type='text'
                value={tradelicense}
                name='tradelicense'
                onChange={'tradelicense'}
                // onBlur={validatetradelicense}
                className='form-group__input'
              />
              {/* <p className='error'>
                {isErrortradelicense && errorMessagetradelicense}
              </p> */}
            </div>
            <div className='form-group__element'>
              <label
                htmlFor='Trade license number'
                className='form-group__label'
              >
                Trade license number
              </label>
              <input
                type='text'
                value={Tradelicensenumber}
                name='Tradelicensenumber'
                onChange={'Tradelicensenumber'}
                onBlur={Tradelicensenumber}
                className='form-group__input'
              />
            </div>
            <div className='form-group__element'>
              <label
                htmlFor='Tradelicenseplaceofissue'
                className='form-group__label'
              >
                Trade license place of issue
              </label>
              <input
                type='text'
                value={Tradelicenseplaceofissue}
                name='Tradelicenseplaceofissue'
                onChange={'Tradelicenseplaceofissue'}
                className='form-group__input'
              />
            </div>
            <div className='form-group__element'>
              <label
                htmlFor='Tradelicenseissuedate'
                className='form-group__label'
              >
                Trade license issue date
              </label>
              <input
                type='text'
                value={Tradelicenseissuedate}
                name='Tradelicenseissuedate'
                onChange={'Tradelicenseissuedate'}
                onBlur={Tradelicenseissuedate}
                className='form-group__input'
              />
            </div>
            <div className='form-group__element'>
              <label
                htmlFor='Tradelicenseexpirydate'
                className='form-group__label'
              >
                Trade license expiry date
              </label>
              <input
                type='text'
                value={Tradelicenseexpirydate}
                name='Tradelicenseexpirydate'
                onChange={'Tradelicenseexpirydate'}
                onBlur={Tradelicenseexpirydate}
                className='form-group__input'
              />
              {/* <p className='error'>
                {isErrorTradelicenseexpirydate &&
                  errorMessageTradelicenseexpirydate}
              </p> */}
            </div>
            <div className='form-group__element'>
              <label
                htmlFor='Typeofbusinessoftheentity'
                className='form-group__label'
              >
                Type of business of the entity
              </label>
              <input
                type='text'
                value={Typeofbusinessoftheentity}
                name='Typeofbusinessoftheentity'
                onChange={'Typeofbusinessoftheentity'}
                className='form-group__input'
              />
            </div>
            <div className='form-group__element'>
              <label htmlFor='Shareholders' className='form-group__label'>
                Share holders
              </label>
              <input
                type='text'
                value={Shareholders}
                name='Shareholders'
                onChange={'Shareholders'}
                onBlur={Shareholders}
                className='form-group__input'
              />
            </div>
            <div className='form-group__element'>
              <label htmlFor='Partners' className='form-group__label'>
                Partners
              </label>
              <input
                type='text'
                value={Partners}
                name='Partners'
                onChange={'Partners'}
                onBlur={Partners}
                className='form-group__input'
              />
            </div>
            <div className='form-group__element'>
              <label htmlFor='NamesofUBO' className='form-group__label'>
                Names of UBO
              </label>
              <input
                type='text'
                value={NamesofUBO}
                name='NamesofUBO'
                onChange={'NamesofUBO'}
                onBlur={NamesofUBO}
                className='form-group__input'
              />
            </div>
            <div className='form-group__element'>
              <label htmlFor='NamesofUBO' className='form-group__label'>
                ID details of UBO
              </label>
              <input
                type='text'
                value={IDdetailsofUBO}
                name='IDdetailsofUBO'
                onChange={'NamesofUBO'}
                onBlur={NamesofUBO}
                className='form-group__input'
              />
            </div>
            <div className='form-group__element'>
              <label htmlFor='IDnumbersofUBO' className='form-group__label'>
                IDtypeofUBO
              </label>
              <input
                type='text'
                value={IDtypeofUBO}
                name='IDtypeofUBO'
                onChange={'IDtypeofUBO'}
                onBlur={IDtypeofUBO}
                className='form-group__input'
              />
            </div>
            <div className='form-group__element'>
              <label htmlFor='IDtypeofUBO' className='form-group__label'>
                IDtypeofUBO
              </label>
              <input
                type='text'
                value={IDtypeofUBO}
                name='IDtypeofUBO'
                onChange={'IDtypeofUBO'}
                onBlur={IDtypeofUBO}
                className='form-group__input'
              />
            </div>
            <div className='form-group__element'>
              <label htmlFor='IDnumbersofUBO' className='form-group__label'>
                IDtypeofUBO
              </label>
              <input
                type='text'
                value={IDtypeofUBO}
                name='IDtypeofUBO'
                onChange={'IDtypeofUBO'}
                onBlur={IDtypeofUBO}
                className='form-group__input'
              />
            </div>
            <div className='form-group__element'>
              <label htmlFor='IDnumbersofUBO' className='form-group__label'>
                IDnumbersofUBO
              </label>
              <input
                type='text'
                value={IDnumbersofUBO}
                name='IDnumbersofUBO'
                onChange={'IDnumbersofUBO'}
                onBlur={IDnumbersofUBO}
                className='form-group__input'
              />
            </div>
            <div className='form-group__element'>
              <label htmlFor='Methodofpayment' className='form-group__label'>
                Methodofpayment
              </label>
              <input
                type='text'
                value={Methodofpayment}
                name='Methodofpayment'
                onChange={'Methodofpayment'}
                onBlur={Methodofpayment}
                className='form-group__input'
              />
            </div>
            <div className='form-group__element'>
              <label htmlFor='cash' className='form-group__label'>
                cash
              </label>
              <input
                type='text'
                value={cash}
                name='cash'
                onChange={'cash'}
                onBlur={cash}
                className='form-group__input'
              />
            </div>
            <div className='form-group__element'>
              <label htmlFor='cheque' className='form-group__label'>
                cheque
              </label>
              <input
                type='text'
                value={cheque}
                name='cheque'
                onChange={'cheque'}
                onBlur={cheque}
                className='form-group__input'
              />
            </div>
            <div className='form-group__element'>
              <label
                htmlFor='Nameofthepersonrepresentingtheentity'
                className='form-group__label'
              >
                Name of the person representing the entity
              </label>
              <input
                type='text'
                value={Nameofthepersonrepresentingtheentity}
                name='Nameofthepersonrepresentingtheentity'
                onChange={'Nameofthepersonrepresentingtheentity'}
                onBlur={Nameofthepersonrepresentingtheentity}
                className='form-group__input'
              />
            </div>
            <div className='form-group__element'>
              <label htmlFor='IDtypeofAuthPerson' className='form-group__label'>
                ID type of Auth Person
              </label>
              <input
                type='text'
                value={IDtypeofAuthPerson}
                name='IDtypeofAuthPerson'
                onChange={'IDtypeofAuthPerson'}
                onBlur={IDtypeofAuthPerson}
                className='form-group__input'
              />
            </div>
            <div className='form-group__element'>
              <label
                htmlFor='IDnumbersofAuthPerson'
                className='form-group__label'
              >
                ID numbers of Auth Person
              </label>
              <input
                type='text'
                value={IDtypeofAuthPerson}
                name='IDtypeofAuthPerson'
                onChange={'IDtypeofAuthPerson'}
                onBlur={IDtypeofAuthPerson}
                className='form-group__input'
              />
            </div>
            <div className='form-group__element'>
              <label
                htmlFor='IDnumbersofAuthPerson'
                className='form-group__label'
              >
                ID numbers of Auth Person
              </label>
              <input
                type='text'
                value={IDnumbersofAuthPerson}
                name='IDnumbersofAuthPerson'
                onChange={'IDnumbersofAuthPerson'}
                onBlur={IDnumbersofAuthPerson}
                className='form-group__input'
              />
            </div>
            <div className='form-group__element'>
              <label htmlFor='Sourceoffunds' className='form-group__label'>
                Source of funds
              </label>
              <input
                type='text'
                value={Sourceoffunds}
                name='Sourceoffunds'
                onChange={'Sourceoffunds'}
                onBlur={Sourceoffunds}
                className='form-group__input'
              />
            </div>
            <div className='form-group__element'>
              <label
                htmlFor='Purposeoftransaction'
                className='form-group__label'
              >
                Purpose of transaction
              </label>
              <input
                type='text'
                value={Purposeoftransaction}
                name='Purposeoftransaction'
                onChange={'Purposeoftransaction'}
                onBlur={Purposeoftransaction}
                className='form-group__input'
              />
            </div>
            <div className='form-group__element'>
              <label htmlFor='Beneficiaryname' className='form-group__label'>
                Beneficiaryname
              </label>
              <input
                type='text'
                value={Beneficiaryname}
                name='Beneficiaryname'
                onChange={'Beneficiaryname'}
                onBlur={Beneficiaryname}
                className='form-group__input'
              />
            </div>
            <div className='form-group__element'>
              <label htmlFor='bankaccountdetails' className='form-group__label'>
                bank account details
              </label>
              <input
                type='text'
                value={bankaccountdetails}
                name='bankaccountdetails'
                onChange={'bankaccountdetails'}
                onBlur={bankaccountdetails}
                className='form-group__input'
              />
            </div>
            <div className='form-group__element'>
              <label
                htmlFor='Expectedannualactivity'
                className='form-group__label'
              >
                Expected annual activity
              </label>
              <input
                type='text'
                value={Expectedannualactivity}
                name='Expectedannualactivity'
                onChange={'Expectedannualactivity'}
                onBlur={Expectedannualactivity}
                className='form-group__input'
              />
            </div>
            <div className='form-group__element'>
              <label
                htmlFor='expectedannualvalue'
                className='form-group__label'
              >
                expected annual value
              </label>
              <input
                type='text'
                value={expectedannualvalue}
                name='expectedannualvalue'
                onChange={'expectedannualvalue'}
                onBlur={expectedannualvalue}
                className='form-group__input'
              />
            </div>

            <div className='form-group__element'>
              <label
                htmlFor='numberoftransactionsfuturetransmonitoring'
                className='form-group__label'
              >
                number of transactions future trans monitoring
              </label>
              <input
                type='text'
                value={numberoftransactionsfuturetransmonitoring}
                name='numberoftransactionsfuturetransmonitoring'
                onChange={'numberoftransactionsfuturetransmonitoring'}
                onBlur={numberoftransactionsfuturetransmonitoring}
                className='form-group__input'
              />
            </div>
          </div>

          <div style={{ textAlign: 'center' }}>
            <button
              className='buttons__button buttons__button--next'
              onClick={this.continue}
            >
              Next
            </button>
          </div>
        </form>
      </div>
    )
  }
}

export default CorpPaymentDetails
