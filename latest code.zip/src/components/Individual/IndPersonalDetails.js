import React, { Component, useState } from 'react'
import { Stepper } from 'react-form-stepper'
import '../../App.css'

class IndPersonalDetails extends Component {
  continue = e => {
    e.preventDefault()

    this.props.nextStep()
  }

  render () {
    const { values } = this.props

    // const {
    //   //firstname,
    //   middlename,
    //   lastname,
    //   residentialstatus,
    //   area,
    //   district,
    //   city,
    //   emiratesorstate,
    //   province,
    //   country,
    //   temporaryaddress,
    //   permanentaddress,
    //   completepermanentaddress,
    //   nationality,
    //   dateofbirth,
    //   coutnryofbirth,
    //   mobilenumber,

    //   // email,
    //   // phone,
    //   handleChange,
    //   validateFirstName,
    //   validateLastName,
    //   isErrorFirstName,
    //   isErrorLastName,
    //   errorMessageFirstName,
    //   errorMessageLastName,
    //   validateMiddleName,
    //   isErrorMiddleName,
    //   errorMessageMiddleName,
    //   ResidentialStatus,
    //   isErrorResidentialStatus,
    //   errorMessageResidentialStatus,
    //   Area,
    //   isErrorArea,
    //   errorMessageArea,
    //   // City,
    //   // isErrorcity,
    //   // errorMessagecity,
    //   // isErroremiratesorstate,
    //   // errorMessageemiratesorstate,
    //   // isErrorprovince,
    //   // errorMessageemiratesorprovince,
    //   // isErrorcountry,
    //   // errorMessageemiratesorcountry,
    //   // isErrortemporaryaddress,
    //   // errorMessagetemporaryaddress,
    //   // isErrorpermanentaddress,
    //   // errorMessagepermanentaddress,
    //   // isErrorcompletepermanentaddress,
    //   // errorMessagecompletepermanentaddress,
    //   // isErrornationality,
    //   // errorMessagenationality,
    //   isErrordateofbirth,
    //   errorMessagedateofbirth,
    //   isErrorcoutnryofbirth,
    //   errorMessagecoutnryofbirth
    // } = this.props

    return (
      // <div className='form'>
      <form>
        <Stepper
          steps={[
            { label: 'Personal details' },
            { label: 'Address details' },
            { label: 'Payment Details' },
            { label: 'Summary' }
          ]}
          activeStep={0}
          styleConfig={{
            activeBgColor: '#2b7cff',
            activeTextColor: '#fff',
            inactiveBgColor: '#fff',
            inactiveTextColor: '#2b7cff',
            completedBgColor: '#fff',
            completedTextColor: '#2b7cff',
            size: '3em'
          }}
          className={'stepper'}
          stepClassName={'stepper__step'}
        />
        <div className='form-group'>
          <div className='form-group__element'>
            <label htmlFor='first name' className='form-group__label'>
              First Name
            </label>
            <input
              type='text'
              onChange={this.props.handleChange('firstName')}
              defaultValue={values.firstName}
              className='form-group__input'
            />
            {/* <p className='error'>{isErrorFirstName && errorMessageFirstName}</p> */}
          </div>
          <div className='form-group__element'>
            <label htmlFor='middle name' className='form-group__label'>
              Middle Name
            </label>
            <input
              type='text'
              onChange={this.props.handleChange('middleName')}
              defaultValue={values.middleName}
              className='form-group__input'
            />
          </div>
          <div className='form-group__element'>
            <label htmlFor='last name' className='form-group__label'>
              Last Name
            </label>
            <input
              type='text'
              onChange={this.props.handleChange('lastName')}
              defaultValue={values.lastName}
              className='form-group__input'
            />
            {/* <p className='error'>{isErrorFirstName && errorMessageFirstName}</p> */}
          </div>

          <div className='form-group__element'>
            <label htmlFor='place Of Birth' className='form-group__label'>
              Place Of Birth
            </label>
            <input
              type='text'
              onChange={this.props.handleChange('placeOfBirth')}
              defaultValue={values.placeOfBirth}
              className='form-group__input'
            />
            {/* <p className='error'>{isErrorFirstName && errorMessageFirstName}</p> */}
          </div>
          <div className='form-group__element'>
            <label htmlFor='Bussiness Type' className='form-group__label'>
              Bussiness Type
            </label>
            <input
              type='text'
              onChange={this.props.handleChange('bussinessType')}
              defaultValue={values.bussinessType}
              className='form-group__input'
            />
            {/* <p className='error'>{isErrorFirstName && errorMessageFirstName}</p> */}
          </div>
          <div className='form-group__element'>
            <label htmlFor='sectorType' className='form-group__label'>
              Sector Type
            </label>
            <input
              type='text'
              onChange={this.props.handleChange('sectorType')}
              defaultValue={values.sectorType}
              className='form-group__input'
            />
            {/* <p className='error'>{isErrorFirstName && errorMessageFirstName}</p> */}
          </div>

          <div className='form-group__element'>
            <label htmlFor='nationality' className='form-group__label'>
              Nationality
            </label>
            <input
              type='text'
              onChange={this.props.handleChange('nationality')}
              defaultValue={values.nationality}
              className='form-group__input'
            />
            {/* <p className='error'>{isErrorFirstName && errorMessageFirstName}</p> */}
          </div>
        </div>
        <div style={{ textAlign: 'center' }}>
          <button
            className='buttons__button buttons__button--next'
            onClick={this.continue}
          >
            Next
          </button>
        </div>
      </form>
    )
  }
}

export default IndPersonalDetails
