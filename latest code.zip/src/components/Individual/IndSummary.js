import axios from 'axios'
import React, { Component, useState } from 'react'
import { Stepper } from 'react-form-stepper'
import '../../App.css'

class IndSummary extends Component {
  // continue = e => {
  //   e.preventDefault()
  //   this.props.nextStep()
  // }
  iddd = JSON.parse(localStorage.getItem('id'))

  back = e => {
    e.preventDefault()
    this.props.prevStep()
  }

  handleSubmitClick = async e => {
    e.preventDefault()

    try {
      const { values } = this.props
      // const uid = '60ba81cf341522149aa99903'
      const at = 'Individual'
      values['userId'] = JSON.parse(localStorage.getItem('id'))
      values['accountType'] = 'Individual'
      const config = {
        headers: {
          Authorization: `Bearer ${JSON.parse(localStorage.getItem('token'))}`
        }
      }

      await axios
        .post('http://kycdigi.ae:4002/personal/personalinfo', values, config)
        .then(function (response) {
          if (response.status === 200) {
            console.log('error', response.data)
            if (response.data.status === 400) {
              alert(response.data.message)
            } else {
              alert(response.data.message)
            }
          } else {
            this.props.showError('Some error ocurred')
          }
        })
    } catch (error) {
      if (error.response) {
        console.log('error', error.response.data)
      }
    }
  }

  // add entity - POST

  // creates entity
  Idd = JSON.parse(localStorage.getItem('id'))

  render () {
    //  const { firstname, profession, emiratesid } = this.props

    //  const { firstname, profession, emiratesid } = this.props
    //Idd = JSON.parse(localStorage.getItem('id'))

    const {
      values: {
        idd,
        firstName,
        Profession,
        emiratesIdNumber,
        lastName,
        middleName,
        placeOfBirth,
        bussinessType,
        sectorType,
        nationality,

        expiryDate,
        country,
        state,
        address1,
        address2,
        idType,
        ResidentialStatus,
        temaddress,
        compermanent,
        email,
        idplaceofIssue,

        //payment details
        methodofpayment,
        sourceoffunds,
        beneficiaryName,
        expectedAnnualActivity,
        phoneNumber,
        faxNumber,
        typeOfBusiness,
        namesOfUBO,
        iddetailsofUB,
        idTypeOfUBO,
        idNumbersOfUBO,
        authPersonName,
        idTypeAuthPerson,
        idNumberAuthPerson
      }
    } = this.props

    // const {
    //   firstname,
    //   // lastname,
    //   // email,
    //   // phone,
    //   // //coursesChosenSummary,
    //   // //chosenLevel,
    //   submitData
    // } = this.props

    return (
      <div className='form'>
        <div>
          <Stepper
            steps={[
              { label: 'Personal details' },
              { label: 'Address details' },
              { label: 'Payment Details' },
              { label: 'Summary' }
            ]}
            activeStep={3}
            styleConfig={{
              activeBgColor: '#2b7cff',
              activeTextColor: '#fff',
              inactiveBgColor: '#fff',
              inactiveTextColor: '#2b7cff',
              completedBgColor: '#fff',
              completedTextColor: '#2b7cff',
              size: '3em'
            }}
            className={'stepper'}
            stepClassName={'stepper__step'}
          />

          <div className='summary'>
            <h2 className='summary__heading'>Confirm your personal details</h2>
            <div>
              <div>
                <p>
                  <span className='summary__item-title'>First Name:</span>
                  {JSON.parse(localStorage.getItem('id'))}
                </p>
                <p>
                  <span className='summary__item-title'>First Name:</span>
                  {firstName}
                </p>
              </div>
              <div>
                <p>
                  <span className='summary__item-title'>Profession :</span>
                  {emiratesIdNumber}
                </p>
              </div>
              <div>
                <p>
                  <span className='summary__item-title'>Emirates ID:</span>
                  {Profession}
                </p>
              </div>
              <div>
                <p>
                  <span className='summary__item-title'>Middle Name:</span>
                  {middleName}
                </p>
              </div>
              <div>
                <p>
                  <span className='summary__item-title'>Last Name:</span>{' '}
                  {lastName}
                </p>
              </div>
              <div>
                <p>
                  <span className='summary__item-title'>Place Of Birth :</span>{' '}
                  {placeOfBirth}
                </p>
              </div>
              <div>
                <p>
                  <span className='summary__item-title'>Bussiness Type :</span>{' '}
                  {bussinessType}
                </p>
              </div>
              <div>
                <p>
                  <span className='summary__item-title'>Sector Type :</span>{' '}
                  {sectorType}
                </p>
              </div>
              <div>
                <p>
                  <span className='summary__item-title'>nationality :</span>{' '}
                  {nationality}
                </p>
              </div>
              <div>
                <p>
                  <span className='summary__item-title'>expiryDate :</span>{' '}
                  {expiryDate}
                </p>
              </div>
              <div>
                <p>
                  <span className='summary__item-title'>country :</span>{' '}
                  {country}
                </p>
              </div>
              <div>
                <p>
                  <span className='summary__item-title'>state :</span> {state}
                </p>
              </div>
              <div>
                <p>
                  <span className='summary__item-title'>address1 :</span>{' '}
                  {address1}
                </p>
              </div>
              <div>
                <p>
                  <span className='summary__item-title'>address2 :</span>{' '}
                  {address2}
                </p>
              </div>
              <div>
                <p>
                  <span className='summary__item-title'>ID Type :</span>{' '}
                  {idType}
                </p>
              </div>
              <div>
                <p>
                  <span className='summary__item-title'>
                    Residential Status :
                  </span>{' '}
                  {ResidentialStatus}
                </p>
              </div>
              <div>
                <p>
                  <span className='summary__item-title'>temaddress :</span>{' '}
                  {temaddress}
                </p>
              </div>
              <div>
                <p>
                  <span className='summary__item-title'>compermanent :</span>{' '}
                  {compermanent}
                </p>
              </div>
              <div>
                <p>
                  <span className='summary__item-title'>email :</span> {email}
                </p>
              </div>
              <div>
                <p>
                  <span className='summary__item-title'>idplaceofIssue :</span>{' '}
                  {idplaceofIssue}
                </p>
              </div>
            </div>
          </div>

          <div className='summary'>
            <h2 className='summary__heading'>Confirm Your Payment Details</h2>
            <div>
              <div>
                <p>
                  <span className='summary__item-title'>methodofpayment: </span>{' '}
                  {methodofpayment}
                </p>
              </div>
              <div>
                <div>
                  <p>
                    <span className='summary__item-title'>sourceoffunds :</span>{' '}
                    {sourceoffunds}
                  </p>
                </div>
                <div>
                  <p>
                    <span className='summary__item-title'>
                      beneficiaryName:
                    </span>{' '}
                    {beneficiaryName}
                  </p>
                </div>
                <div>
                  <p>
                    <span className='summary__item-title'>
                      expectedAnnualActivity :
                    </span>{' '}
                    {expectedAnnualActivity}
                  </p>
                </div>
                <div>
                  <p>
                    <span className='summary__item-title'>phoneNumber:</span>{' '}
                    {phoneNumber}
                  </p>
                </div>
                <div>
                  <p>
                    <span className='summary__item-title'>faxNumber :</span>{' '}
                    {faxNumber}
                  </p>
                </div>
                <div>
                  <p>
                    <span className='summary__item-title'>typeOfBusiness:</span>{' '}
                    {typeOfBusiness}
                  </p>
                </div>
                <div>
                  <p>
                    <span className='summary__item-title'>namesOfUBO :</span>{' '}
                    {namesOfUBO}
                  </p>
                </div>
                <div>
                  <p>
                    <span className='summary__item-title'>iddetailsofUB:</span>{' '}
                    {iddetailsofUB}
                  </p>
                </div>
                <div>
                  <p>
                    <span className='summary__item-title'>idTypeOfUBO :</span>{' '}
                    {idTypeOfUBO}
                  </p>
                </div>
                <div>
                  <p>
                    <span className='summary__item-title'>
                      idNumbersOfUBO :
                    </span>{' '}
                    {idNumbersOfUBO}
                  </p>
                </div>
                <div>
                  <p>
                    <span className='summary__item-title'>
                      authPersonName :
                    </span>{' '}
                    {authPersonName}
                  </p>
                </div>
                <div>
                  <p>
                    <span className='summary__item-title'>
                      idTypeAuthPerson :
                    </span>{' '}
                    {idTypeAuthPerson}
                  </p>
                </div>
                <div>
                  <p>
                    <span className='summary__item-title'>
                      idNumberAuthPerson :
                    </span>{' '}
                    {idNumberAuthPerson}
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className='buttons'>
            <button
              className='buttons__button buttons__button--back'
              onClick={this.back}
            >
              Back
            </button>
            <button
              className='buttons__button buttons__button--next'
              type='submit'
              onClick={this.handleSubmitClick}
            >
              Submit
            </button>
          </div>
        </div>
      </div>
    )
  }
}

export default IndSummary
